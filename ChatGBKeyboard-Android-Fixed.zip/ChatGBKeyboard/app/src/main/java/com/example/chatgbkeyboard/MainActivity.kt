package com.example.chatgbkeyboard

import android.app.Activity
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.content.Intent
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("chatgb", Context.MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 32, 24, 24)
        }
        root.addView(TextView(this).apply {
            text = "ChatGB Keyboard"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "AI writing tools built into your Android keyboard."
            textSize = 16f
        })
        val url = EditText(this).apply {
            hint = "Your secure AI backend URL (https://...)"
            setText(prefs.getString("backend_url", ""))
            setSingleLine(true)
        }
        root.addView(url)
        root.addView(Button(this).apply {
            text = "Save backend URL"
            setOnClickListener {
                prefs.edit().putString("backend_url", url.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "Enable ChatGB Keyboard"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        })
        root.addView(Button(this).apply {
            text = "Switch to ChatGB Keyboard"
            setOnClickListener {
                (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
            }
        })
        root.addView(TextView(this).apply {
            text = "\nSetup:\n1. Deploy the included backend and enter its HTTPS URL.\n2. Enable ChatGB Keyboard in Android keyboard settings.\n3. Select it from the keyboard picker.\n\nThe backend keeps your OpenAI API key off the phone."
            textSize = 14f
        })
        setContentView(root)
    }
}
