import express from "express";

const app = express();
app.use(express.json({ limit: "20kb" }));

app.post("/rewrite", async (req, res) => {
  try {
    const prompt = String(req.body?.prompt || "").slice(0, 6000);
    if (!prompt) return res.status(400).json({ error: "Prompt is required" });
    if (!process.env.OPENAI_API_KEY) return res.status(500).json({ error: "Server is missing OPENAI_API_KEY" });

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-5.5",
        instructions: "You are a helpful writing assistant inside an Android keyboard. Return only the finished text, without quotation marks or explanations.",
        input: prompt,
        max_output_tokens: 300
      })
    });
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.error?.message || "OpenAI request failed" });
    res.json({ text: data.output_text || "" });
  } catch (err) {
    res.status(500).json({ error: "Backend request failed" });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`ChatGB backend listening on ${port}`));
