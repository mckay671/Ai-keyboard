# ChatGB Keyboard (Android starter)

A native Android Input Method Editor (IME) with basic QWERTY typing and AI writing actions.

## Included
- Android keyboard service
- Rewrite, grammar fix, reply and funny-tone actions
- Insert button to place the generated result into the active text field
- Small Node.js backend using the OpenAI Responses API

## Important
This is a starter project, not a finished Play Store keyboard. It has a deliberately simple key layout; shift/caps, number/symbol pages, suggestions, autocorrect, swipe typing, accessibility polish, privacy controls and production testing still need work.

**Never put an OpenAI API key in the Android app.** The app calls your backend; the backend stores the key as an environment variable. OpenAI explicitly advises against exposing API keys in mobile apps: https://developers.openai.com/api/docs/guides/api-keys

## Backend setup
1. Install Node.js 20 or newer.
2. In `backend/`, run `npm install`.
3. Set `OPENAI_API_KEY` on the server as an environment variable.
4. Optionally set `OPENAI_MODEL` (defaults to `gpt-5.5` in this starter).
5. Run `npm start`.
6. Deploy behind HTTPS and use that HTTPS URL in the Android app.

Example (macOS/Linux):
```bash
cd backend
npm install
export OPENAI_API_KEY="your-key"
npm start
```

Do not use the example command with a real key on a shared computer. Prefer your hosting provider's secret/environment-variable manager.

## Android build
1. Open this folder in Android Studio (recent version).
2. Let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the APK on your Android phone.
5. Open ChatGB Keyboard, enter your backend HTTPS URL, save it.
6. Tap Enable ChatGB Keyboard and enable it in Android settings.
7. Return and tap Switch to ChatGB Keyboard.

## Privacy and permissions
Android keyboards can process everything typed into them. This starter sends only the selected text (or up to 300 characters immediately before the cursor) when you explicitly tap an AI action. Review and improve this behaviour, add a clear privacy notice, and avoid sending passwords or sensitive content. Do not publish until you have tested the IME across target apps and Android versions.

## API
The backend calls `POST https://api.openai.com/v1/responses`. See:
https://developers.openai.com/api/reference/resources/responses/methods/create
