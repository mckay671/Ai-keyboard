package com.example.chatgbkeyboard

import android.inputmethodservice.InputMethodService
import android.view.View
import android.view.Gravity
import android.view.inputmethod.InputConnection
import android.graphics.Color
import android.widget.*
import android.text.TextUtils
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class ChatGBInputMethod : InputMethodService() {
    private lateinit var resultText: TextView
    private lateinit var insertButton: Button
    private var latestAnswer: String = ""

    override fun onCreateInputView(): View {
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(6, 6, 6, 6)
            setBackgroundColor(Color.rgb(235, 238, 245))
        }
        val aiBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        resultText = TextView(this).apply {
            text = "ChatGB AI · Select text, then choose a tool"
            textSize = 12f
            setTextColor(Color.DKGRAY)
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
        }
        aiBar.addView(resultText, LinearLayout.LayoutParams(0, 48, 1f))
        insertButton = Button(this).apply {
            text = "Insert"
            isEnabled = false
            setOnClickListener {
                currentInputConnection?.commitText(latestAnswer, 1)
                resultText.text = "Inserted"
            }
        }
        aiBar.addView(insertButton)
        panel.addView(aiBar)

        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addTool(tools, "Rewrite") { runAi("Rewrite this text clearly and naturally. Keep the meaning: ") }
        addTool(tools, "Fix") { runAi("Correct spelling and grammar only: ") }
        addTool(tools, "Reply") { runAi("Write a concise, friendly reply to this message: ") }
        addTool(tools, "Funny") { runAi("Rewrite this in a funny, playful tone: ") }
        panel.addView(tools)

        val rows = listOf("qwertyuiop", "asdfghjkl", "⇧zxcvbnm⌫")
        rows.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { ch ->
                val label = when (ch) { '⇧' -> "⇧"; '⌫' -> "⌫"; else -> ch.toString() }
                val b = Button(this).apply {
                    text = label
                    textSize = 16f
                    isAllCaps = false
                    setPadding(0, 0, 0, 0)
                    setOnClickListener { handleKey(ch) }
                }
                line.addView(b, LinearLayout.LayoutParams(0, 48, if (ch == '⇧' || ch == '⌫') 1.4f else 1f).apply {
                    setMargins(2, 2, 2, 2)
                })
            }
            panel.addView(line)
        }
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addBottomKey(bottom, "?123", 1.4f) { commit("123") }
        addBottomKey(bottom, ",", 1f) { commit(",") }
        addBottomKey(bottom, "English", 4f) { commit(" ") }
        addBottomKey(bottom, ".", 1f) { commit(".") }
        addBottomKey(bottom, "↵", 1.4f) { currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER)); currentInputConnection?.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, android.view.KeyEvent.KEYCODE_ENTER)) }
        panel.addView(bottom)
        return panel
    }

    private fun addTool(row: LinearLayout, label: String, action: () -> Unit) {
        row.addView(Button(this).apply {
            text = label
            textSize = 11f
            isAllCaps = false
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(0, 44, 1f))
    }

    private fun addBottomKey(row: LinearLayout, label: String, weight: Float, action: () -> Unit) {
        row.addView(Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setOnClickListener { action() }
        }, LinearLayout.LayoutParams(0, 48, weight).apply { setMargins(2, 2, 2, 2) })
    }

    private fun handleKey(ch: Char) {
        when (ch) {
            '⌫' -> currentInputConnection?.deleteSurroundingText(1, 0)
            '⇧' -> resultText.text = "Shift is not implemented in this starter"
            else -> commit(ch.toString())
        }
    }

    private fun commit(value: String) { currentInputConnection?.commitText(value, 1) }

    private fun runAi(prefix: String) {
        val selected = currentInputConnection?.getSelectedText(0)?.toString().orEmpty()
        val before = currentInputConnection?.getTextBeforeCursor(300, 0)?.toString().orEmpty()
        val text = if (selected.isNotBlank()) selected else before
        if (text.isBlank()) {
            resultText.text = "Select text or type a message first"
            return
        }
        val prefs = getSharedPreferences("chatgb", MODE_PRIVATE)
        val endpoint = prefs.getString("backend_url", "")?.trim().orEmpty()
        if (endpoint.isBlank()) {
            resultText.text = "Set your backend URL in the ChatGB app first"
            return
        }
        resultText.text = "Thinking…"
        insertButton.isEnabled = false
        thread {
            try {
                val conn = (URL(endpoint.trimEnd('/') + "/rewrite").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 30000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(JSONObject().put("prompt", prefix + text).toString().toByteArray()) }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val answer = JSONObject(body).optString("text")
                runOnUiThread {
                    latestAnswer = answer
                    resultText.text = answer
                    insertButton.isEnabled = answer.isNotBlank()
                }
                conn.disconnect()
            } catch (e: Exception) {
                runOnUiThread { resultText.text = "AI error: ${e.message ?: "Could not connect"}" }
            }
        }
    }
}
